# Instrukcja kompilacji
Należy wpisać w terminalu `make`.
# Instrukcja uruchomienia
Należy wpisać w teminalu `./serwer` w celu uruchomienia serwera oraz `./klient` w celu uruchomienia klienta.
# Zawartość plików
`inf151736_inf151756.h` - definicje i struktury
`inf151736_inf151756_s.c` - kod serwera
`inf151736_inf151756_k.c` - kod klienta